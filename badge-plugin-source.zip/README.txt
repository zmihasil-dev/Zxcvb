Свой значок — плагин для margyT (.mtp). Сборка: ./build.sh
