package badge.margyt;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

/** Настройки значка и сам значок (хранятся в приватной папке TikTok, на сервер ничего не уходит). */
final class BadgeStore {

    static final int ICON_SIZE = 192;

    private final Context ctx;
    private final SharedPreferences prefs; // может быть null — тогда настройки живут до перезапуска
    String username = "";
    String dispname = "";
    boolean enabled = true;
    Bitmap badge;

    BadgeStore(Context ctx, SharedPreferences prefs) {
        this.ctx = ctx;
        this.prefs = prefs;
        load();
    }

    private File file() {
        return new File(ctx.getFilesDir(), "margyt_badge.png");
    }

    void load() {
        try {
            if (prefs != null) {
                username = prefs.getString("username", "");
                dispname = prefs.getString("dispname", "");
                enabled = prefs.getBoolean("enabled", true);
            }
            File f = file();
            if (f.exists()) badge = BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Throwable ignored) {
        }
    }

    void saveText(String user, String disp, boolean on) {
        username = user == null ? "" : user.trim();
        dispname = disp == null ? "" : disp.trim();
        enabled = on;
        try {
            if (prefs != null) {
                prefs.edit().putString("username", username).putString("dispname", dispname)
                        .putBoolean("enabled", enabled).apply();
            }
        } catch (Throwable ignored) {
        }
    }

    boolean setImage(Bitmap square) {
        try {
            FileOutputStream out = new FileOutputStream(file());
            try {
                square.compress(Bitmap.CompressFormat.PNG, 100, out);
            } finally {
                out.close();
            }
            badge = square;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    void clearImage() {
        try {
            file().delete();
        } catch (Throwable ignored) {
        }
        badge = null;
    }

    boolean ready() {
        return enabled && badge != null && (norm(username).length() > 0 || norm(dispname).length() > 0);
    }

    /** Ник без @, в нижнем регистре, без пробелов по краям. */
    static String norm(CharSequence s) {
        if (s == null) return "";
        String t = s.toString().trim().toLowerCase(Locale.US);
        while (t.startsWith("@")) t = t.substring(1);
        return t.trim();
    }

    /** Читает картинку из галереи с уменьшением (для миниатюр). */
    static Bitmap decodeSampled(ContentResolver cr, Uri uri, int target) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = cr.openInputStream(uri);
        try {
            BitmapFactory.decodeStream(in, null, o);
        } finally {
            if (in != null) in.close();
        }
        int s = 1;
        while (Math.min(o.outWidth, o.outHeight) / (s * 2) >= target) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        in = cr.openInputStream(uri);
        try {
            return BitmapFactory.decodeStream(in, null, o2);
        } finally {
            if (in != null) in.close();
        }
    }

    /** Берёт квадрат по центру фото и уменьшает до размера значка. */
    static Bitmap decodeSquare(ContentResolver cr, Uri uri, int size) throws Exception {
        Bitmap b = decodeSampled(cr, uri, size);
        if (b == null) return null;
        int m = Math.min(b.getWidth(), b.getHeight());
        Bitmap sq = Bitmap.createBitmap(b, (b.getWidth() - m) / 2, (b.getHeight() - m) / 2, m, m);
        return Bitmap.createScaledBitmap(sq, size, size, true);
    }
}
