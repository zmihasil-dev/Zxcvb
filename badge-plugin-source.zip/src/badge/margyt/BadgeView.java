package badge.margyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.text.Layout;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * Прозрачный слой поверх приложения. Находит на экране надписи с твоим ником и рисует рядом
 * твой значок. Видно только на этом телефоне. Касания проходят в приложение, кроме маленькой
 * кнопки настроек.
 */
final class BadgeView extends View {

    interface Logger {
        void log(String s);
    }

    private final BadgeStore store;
    private final Logger logger;
    private final float dp;
    private final int slop;

    private final ArrayList<WeakReference<TextView>> targets = new ArrayList<WeakReference<TextView>>();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final int[] loc = new int[2];
    private final int[] own = new int[2];

    private Activity activity;
    private Bitmap shaderBmp;
    private Shader shader;
    private boolean running, drawFailed;
    private long lastScan;

    // кнопка настроек
    private float bx = -1f, by = -1f;
    private final float br;
    private boolean downOnBtn, dragging;
    private float downX, downY, offX, offY;

    private final Runnable stepper = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            step();
            postOnAnimation(this);
        }
    };

    BadgeView(Context context, BadgeStore store, Logger logger) {
        super(context);
        this.store = store;
        this.logger = logger;
        this.dp = context.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.br = 17f * dp;
        setWillNotDraw(false);
        line.setStyle(Paint.Style.STROKE);
    }

    void setActivity(Activity a) {
        activity = a;
    }

    void clearActivity(Activity a) {
        if (activity == a) activity = null;
    }

    void destroy() {
        running = false;
        removeCallbacks(stepper);
        targets.clear();
    }

    /** Вызывается после изменения настроек. */
    void refresh() {
        targets.clear();
        lastScan = 0L;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (bx < 0f) {
            bx = 8f * dp + br;
            by = h * 0.30f;
        }
        bx = clamp(bx, br, w - br);
        by = clamp(by, br, h - br);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        removeCallbacks(stepper);
        postOnAnimation(stepper);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(stepper);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------ поиск ника на экране

    private void step() {
        try {
            long now = SystemClock.uptimeMillis();
            if (store.ready() && now - lastScan > 120) {
                lastScan = now;
                ViewParent p = getParent();
                if (p instanceof View) {
                    ArrayList<WeakReference<TextView>> found = new ArrayList<WeakReference<TextView>>();
                    collect((View) p, 0, BadgeStore.norm(store.username), BadgeStore.norm(store.dispname), found);
                    targets.clear();
                    targets.addAll(found);
                }
            }
            invalidate();
        } catch (Throwable t) {
            safeLog("badge: step failed: " + t);
        }
    }

    private void collect(View v, int depth, String u, String d, ArrayList<WeakReference<TextView>> out) {
        if (v == this || depth > 70) return;
        if (v.getVisibility() != 0) return;
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.length() > 0 && t.length() <= 80) {
                String n = BadgeStore.norm(t);
                if (n.length() > 0 && (n.equals(u) || n.equals(d))) {
                    out.add(new WeakReference<TextView>((TextView) v));
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            int n = g.getChildCount();
            for (int i = 0; i < n; i++) collect(g.getChildAt(i), depth + 1, u, d, out);
        }
    }

    // ------------------------------------------------------------ касания

    private boolean hitButton(float x, float y) {
        float rr = br + 10f * dp;
        float dx = x - bx, dy = y - by;
        return dx * dx + dy * dy <= rr * rr;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        try {
            int a = e.getActionMasked();
            float x = e.getX(), y = e.getY();
            if (a == MotionEvent.ACTION_DOWN) {
                downOnBtn = hitButton(x, y);
                if (downOnBtn) {
                    dragging = false;
                    downX = x;
                    downY = y;
                    offX = bx - x;
                    offY = by - y;
                    ViewParent p = getParent();
                    if (p != null) p.requestDisallowInterceptTouchEvent(true);
                }
                return downOnBtn;
            }
            if (!downOnBtn) return false;
            if (a == MotionEvent.ACTION_MOVE) {
                if (!dragging) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.sqrt(dx * dx + dy * dy) > slop * 1.5f) dragging = true;
                }
                if (dragging) {
                    bx = clamp(x + offX, br, getWidth() - br);
                    by = clamp(y + offY, br, getHeight() - br);
                }
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                downOnBtn = false;
                boolean tap = a == MotionEvent.ACTION_UP && !dragging;
                dragging = false;
                if (tap) openSettings();
                return true;
            }
            return true;
        } catch (Throwable t) {
            safeLog("badge: touch failed: " + t);
            return false;
        }
    }

    private void openSettings() {
        Activity a = activity;
        if (a == null) return;
        try {
            SettingsUi.showSettings(a, store, this);
        } catch (Throwable t) {
            safeLog("badge: settings failed: " + t);
        }
    }

    // ------------------------------------------------------------ рисование

    @Override
    protected void onDraw(Canvas c) {
        try {
            drawBadges(c);
            drawButton(c);
        } catch (Throwable t) {
            if (!drawFailed) {
                drawFailed = true;
                safeLog("badge: draw failed: " + t);
            }
        }
    }

    private void drawBadges(Canvas c) {
        Bitmap bmp = store.badge;
        if (bmp == null || !store.ready() || targets.isEmpty()) return;
        if (bmp != shaderBmp) {
            shaderBmp = bmp;
            shader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        }
        getLocationOnScreen(own);
        float w = getWidth(), h = getHeight();
        for (int i = targets.size() - 1; i >= 0; i--) {
            TextView tv = targets.get(i).get();
            if (tv == null || !tv.isShown() || tv.getWidth() <= 0) {
                targets.remove(i);
                continue;
            }
            Layout lay = tv.getLayout();
            if (lay == null || lay.getLineCount() == 0) continue;
            tv.getLocationOnScreen(loc);
            float size = clamp(tv.getTextSize() * 1.3f, 16f * dp, 44f * dp);
            float cy = loc[1] - own[1] + tv.getExtendedPaddingTop()
                    + (lay.getLineTop(0) + lay.getLineBottom(0)) / 2f;
            float cx;
            Drawable[] cd = tv.getCompoundDrawables();
            if (cd[2] != null) {
                // у ника уже есть значок справа (например, галочка) — закрываем его своим
                cx = loc[0] - own[0] + tv.getWidth() - tv.getPaddingRight() - cd[2].getBounds().width() / 2f;
                size = Math.max(size, cd[2].getBounds().width() * 1.05f);
            } else {
                cx = loc[0] - own[0] + tv.getCompoundPaddingLeft() + lay.getLineRight(0) + 3f * dp + size / 2f;
            }
            if (cx < 0f || cx > w || cy < 0f || cy > h) continue;

            float sc = size / bmp.getWidth();
            fill.setShader(shader);
            c.save();
            c.translate(cx - size / 2f, cy - size / 2f);
            c.scale(sc, sc);
            c.drawCircle(bmp.getWidth() / 2f, bmp.getHeight() / 2f, bmp.getWidth() / 2f, fill);
            c.restore();
            fill.setShader(null);
            line.setStrokeWidth(1.5f * dp);
            line.setColor(0xCCFFFFFF);
            c.drawCircle(cx, cy, size / 2f, line);
        }
    }

    private void drawButton(Canvas c) {
        if (bx < 0f) return;
        fill.setShader(null);
        fill.setColor(0x99202330);
        c.drawCircle(bx, by, br, fill);
        line.setStrokeWidth(1.2f * dp);
        line.setColor(0xAAFFFFFF);
        c.drawCircle(bx, by, br, line);
        // звезда
        path.reset();
        for (int k = 0; k < 10; k++) {
            float a = (float) (-Math.PI / 2.0 + k * Math.PI / 5.0);
            float r = (k % 2 == 0) ? 0.62f * br : 0.27f * br;
            float px = bx + (float) Math.cos(a) * r, py = by + (float) Math.sin(a) * r;
            if (k == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();
        fill.setColor(store.ready() ? 0xFFFFD34D : 0xFFFFFFFF);
        c.drawPath(path, fill);
    }

    private void safeLog(String s) {
        try {
            logger.log(s);
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
