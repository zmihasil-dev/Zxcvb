package badge.margyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/** Окна настроек и выбор фото из галереи (всё рисуется кодом, ресурсов в плагине нет). */
final class SettingsUi {

    private SettingsUi() {
    }

    // ------------------------------------------------------------ вспомогательное

    private static float dp(Activity a) {
        return a.getResources().getDisplayMetrics().density;
    }

    private static GradientDrawable round(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private static TextView label(Activity a, String text, float sp, int color) {
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private static TextView button(Activity a, String text, int bg) {
        float dp = dp(a);
        TextView t = label(a, text, 15f, 0xFFFFFFFF);
        t.setGravity(17);
        t.setPadding((int) (14 * dp), (int) (11 * dp), (int) (14 * dp), (int) (11 * dp));
        t.setBackground(round(bg, 12 * dp));
        return t;
    }

    private static EditText field(Activity a, String hint, String value) {
        float dp = dp(a);
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setTextColor(0xFFFFFFFF);
        e.setHintTextColor(0xFF8A8D99);
        e.setTextSize(16f);
        e.setPadding((int) (12 * dp), (int) (10 * dp), (int) (12 * dp), (int) (10 * dp));
        e.setBackground(round(0xFF2B2D36, 10 * dp));
        return e;
    }

    private static LinearLayout.LayoutParams lp(int w, int h, int top, float dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, (int) (top * dp), 0, 0);
        return p;
    }

    private static void toast(Activity a, String s) {
        try {
            Toast.makeText(a, s, Toast.LENGTH_LONG).show();
        } catch (Throwable ignored) {
        }
    }

    private static void showDialog(Activity a, Dialog d, View content, float widthFrac) {
        d.setContentView(content);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setLayout((int) (a.getResources().getDisplayMetrics().widthPixels * widthFrac),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setSoftInputMode(0x10);
        }
        d.show();
    }

    /** Круглая версия значка для предпросмотра. */
    private static Bitmap circle(Bitmap src) {
        int s = src.getWidth();
        Bitmap out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        c.drawCircle(s / 2f, s / 2f, s / 2f, p);
        return out;
    }

    // ------------------------------------------------------------ главное окно

    static void showSettings(final Activity a, final BadgeStore store, final BadgeView owner) {
        final float dp = dp(a);
        final Dialog d = new Dialog(a);
        final int pad = (int) (18 * dp);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        box.setBackground(round(0xFF1E1F26, 18 * dp));

        final int W = ViewGroup.LayoutParams.MATCH_PARENT, H = ViewGroup.LayoutParams.WRAP_CONTENT;

        box.addView(label(a, "Свой значок", 21f, 0xFFFFFFFF), lp(W, H, 0, dp));
        box.addView(label(a, "Рисуется рядом с твоим ником в профиле и в видео. Виден только на этом телефоне.",
                13f, 0xFF9DA0AE), lp(W, H, 4, dp));

        box.addView(label(a, "Твой ник (без @)", 13f, 0xFFB8BBC8), lp(W, H, 14, dp));
        final EditText user = field(a, "например, margyt", store.username);
        box.addView(user, lp(W, H, 4, dp));

        box.addView(label(a, "Имя в профиле (необязательно)", 13f, 0xFFB8BBC8), lp(W, H, 12, dp));
        final EditText disp = field(a, "как написано сверху в профиле", store.dispname);
        box.addView(disp, lp(W, H, 4, dp));

        // предпросмотр и кнопки значка
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(16);
        final ImageView preview = new ImageView(a);
        preview.setBackground(round(0xFF2B2D36, 36 * dp));
        if (store.badge != null) preview.setImageBitmap(circle(store.badge));
        row.addView(preview, new LinearLayout.LayoutParams((int) (72 * dp), (int) (72 * dp)));

        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView pick = button(a, "Выбрать из галереи", 0xFF4B6BFF);
        TextView clear = button(a, "Убрать значок", 0xFF3A3C48);
        col.addView(pick, lp(W, H, 0, dp));
        col.addView(clear, lp(W, H, 8, dp));
        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, H, 1f);
        colLp.setMargins((int) (12 * dp), 0, 0, 0);
        row.addView(col, colLp);
        box.addView(row, lp(W, H, 14, dp));

        final boolean[] on = {store.enabled};
        final TextView toggle = button(a, on[0] ? "Значок: включён" : "Значок: выключен", 0xFF2F6F4E);
        box.addView(toggle, lp(W, H, 12, dp));

        TextView save = button(a, "Сохранить", 0xFFE0702A);
        box.addView(save, lp(W, H, 14, dp));

        final Runnable refreshPreview = new Runnable() {
            @Override
            public void run() {
                if (store.badge != null) preview.setImageBitmap(circle(store.badge));
                else preview.setImageBitmap(null);
            }
        };

        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery(a, store, new Runnable() {
                    @Override
                    public void run() {
                        refreshPreview.run();
                        owner.refresh();
                    }
                });
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                store.clearImage();
                refreshPreview.run();
                owner.refresh();
            }
        });
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                on[0] = !on[0];
                toggle.setText(on[0] ? "Значок: включён" : "Значок: выключен");
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                store.saveText(user.getText().toString(), disp.getText().toString(), on[0]);
                owner.refresh();
                d.dismiss();
                if (store.badge == null) toast(a, "Выбери фото для значка");
                else if (BadgeStore.norm(store.username).length() == 0 && BadgeStore.norm(store.dispname).length() == 0) {
                    toast(a, "Впиши свой ник, иначе значку не к чему прикрепляться");
                }
            }
        });

        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        showDialog(a, d, sv, 0.92f);
    }

    // ------------------------------------------------------------ доступ к фото и галерея

    private static boolean granted(Activity a, String perm) {
        return a.checkSelfPermission(perm) == 0;
    }

    private static boolean hasMediaAccess(Activity a) {
        if (Build.VERSION.SDK_INT >= 33) {
            if (granted(a, "android.permission.READ_MEDIA_IMAGES")) return true;
            return Build.VERSION.SDK_INT >= 34 && granted(a, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
        }
        return granted(a, "android.permission.READ_EXTERNAL_STORAGE");
    }

    static void openGallery(final Activity a, final BadgeStore store, final Runnable onPicked) {
        if (hasMediaAccess(a)) {
            showGallery(a, store, onPicked);
            return;
        }
        String[] perms;
        if (Build.VERSION.SDK_INT >= 34) {
            perms = new String[]{"android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"};
        } else if (Build.VERSION.SDK_INT >= 33) {
            perms = new String[]{"android.permission.READ_MEDIA_IMAGES"};
        } else {
            perms = new String[]{"android.permission.READ_EXTERNAL_STORAGE"};
        }
        toast(a, "Разреши доступ к фото — после этого откроется галерея");
        try {
            a.requestPermissions(perms, 7041);
        } catch (Throwable t) {
            toast(a, "Не удалось запросить доступ к фото");
            return;
        }
        // результат запроса плагину недоступен, поэтому просто ждём, пока доступ появится
        final Handler h = new Handler(Looper.getMainLooper());
        final int[] tries = {0};
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (hasMediaAccess(a)) {
                    showGallery(a, store, onPicked);
                    return;
                }
                tries[0]++;
                if (tries[0] < 100) {
                    h.postDelayed(this, 600);
                } else {
                    toast(a, "Доступа к фото нет. Включи его в настройках приложения (Разрешения → Фото).");
                }
            }
        }, 800);
    }

    private static ArrayList<Uri> queryImages(Activity a, int limit) {
        ArrayList<Uri> list = new ArrayList<Uri>();
        Cursor c = null;
        try {
            Uri base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            c = a.getContentResolver().query(base, new String[]{MediaStore.Images.Media._ID}, null, null,
                    MediaStore.Images.Media.DATE_ADDED + " DESC");
            while (c != null && c.moveToNext() && list.size() < limit) {
                list.add(ContentUris.withAppendedId(base, c.getLong(0)));
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }
        return list;
    }

    static void showGallery(final Activity a, final BadgeStore store, final Runnable onPicked) {
        final float dp = dp(a);
        final Dialog d = new Dialog(a);
        final Handler ui = new Handler(Looper.getMainLooper());
        final ContentResolver cr = a.getContentResolver();
        final boolean[] closed = {false};
        final int pad = (int) (12 * dp);
        final int W = ViewGroup.LayoutParams.MATCH_PARENT, H = ViewGroup.LayoutParams.WRAP_CONTENT;

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        box.setBackground(round(0xFF1E1F26, 18 * dp));
        box.addView(label(a, "Выбери фото для значка", 18f, 0xFFFFFFFF), lp(W, H, 0, dp));

        final ArrayList<Uri> uris = queryImages(a, 150);
        final ArrayList<ImageView> cells = new ArrayList<ImageView>();
        int total = (int) (a.getResources().getDisplayMetrics().widthPixels * 0.92f) - 2 * pad;
        int cell = total / 3;

        LinearLayout grid = new LinearLayout(a);
        grid.setOrientation(LinearLayout.VERTICAL);
        if (uris.isEmpty()) {
            grid.addView(label(a, "Фото не найдены или нет доступа к галерее.", 14f, 0xFF9DA0AE), lp(W, H, 12, dp));
        }
        LinearLayout row = null;
        for (int i = 0; i < uris.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row, lp(W, H, 0, dp));
            }
            final Uri uri = uris.get(i);
            ImageView iv = new ImageView(a);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(0xFF2B2D36, 0f));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(cell, cell);
            cp.setMargins(1, 1, 1, 1);
            row.addView(iv, cp);
            cells.add(iv);
            iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    toast(a, "Загружаю значок…");
                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                final Bitmap b = BadgeStore.decodeSquare(cr, uri, BadgeStore.ICON_SIZE);
                                final boolean ok = b != null && store.setImage(b);
                                ui.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        closed[0] = true;
                                        d.dismiss();
                                        if (ok) {
                                            onPicked.run();
                                        } else {
                                            toast(a, "Не получилось прочитать это фото");
                                        }
                                    }
                                });
                            } catch (Throwable e) {
                                ui.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        toast(a, "Не получилось прочитать это фото");
                                    }
                                });
                            }
                        }
                    });
                    t.setDaemon(true);
                    t.start();
                }
            });
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(grid);
        box.addView(sv, lp(W, (int) (a.getResources().getDisplayMetrics().heightPixels * 0.62f), 8, dp));

        TextView cancel = button(a, "Отмена", 0xFF3A3C48);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closed[0] = true;
                d.dismiss();
            }
        });
        box.addView(cancel, lp(W, H, 8, dp));
        showDialog(a, d, box, 0.92f);

        // миниатюры подгружаются по очереди в фоне
        Thread loader = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < uris.size() && !closed[0]; i++) {
                    try {
                        final Bitmap b = BadgeStore.decodeSampled(cr, uris.get(i), 220);
                        final ImageView iv = cells.get(i);
                        if (b != null) {
                            ui.post(new Runnable() {
                                @Override
                                public void run() {
                                    iv.setImageBitmap(b);
                                }
                            });
                        }
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        loader.setDaemon(true);
        loader.start();
    }
}
